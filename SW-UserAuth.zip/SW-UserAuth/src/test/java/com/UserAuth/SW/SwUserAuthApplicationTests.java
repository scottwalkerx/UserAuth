package com.UserAuth.SW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwUserAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
